# autopsy_full_analysis.py
# ---------------------------------------------------------
# Comprehensive Autopsy Research Analysis
# - creates PNG + CSV for each plot
# - embeds histograms into a single Excel workbook for thesis copy/paste
# - re-analyzes items 11, 12, 16 carefully (cleaning & normalization)
# - exports dataset_for_weka.csv
# ---------------------------------------------------------

import os
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# Excel image insertion
import xlsxwriter

plt.rcParams["figure.figsize"] = (10, 6)

# ---------- CONFIG ----------
INPUT_FILE = "NewData.csv"   # change to your filename (csv or xlsx)
OUT_DIR = Path("analysis_outputs")
OUT_DIR.mkdir(exist_ok=True)
IMG_DIR = OUT_DIR / "figures"
IMG_DIR.mkdir(exist_ok=True)
CSV_DIR = OUT_DIR / "csvs"
CSV_DIR.mkdir(exist_ok=True)
# Excel workbook for histograms
HIST_EXCEL = OUT_DIR / "histograms_for_thesis.xlsx"

# ---------- Helpers ----------
def read_input(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")
    if path.suffix.lower() in [".csv"]:
        # try utf-8 then cp1252
        try:
            return pd.read_csv(path, encoding="utf-8")
        except UnicodeDecodeError:
            print("[INFO] UTF-8 failed, trying cp1252/latin1...")
            return pd.read_csv(path, encoding="cp1252")
    elif path.suffix.lower() in [".xls", ".xlsx"]:
        return pd.read_excel(path, engine="openpyxl")
    else:
        raise ValueError("Unsupported file type. Use .csv or .xlsx/.xls")

def find_col(df, *keywords):
    """Find a column name in df whose name contains any of the keywords (case-insensitive)."""
    cols = df.columns
    lowmap = {c.lower(): c for c in cols}
    for key in keywords:
        k = key.lower()
        for lc, orig in lowmap.items():
            if k in lc:
                return orig
    return None

def tokens_from_cell(val, delimiters=[",",";","|","/","\n"]):
    if pd.isna(val):
        return []
    if isinstance(val, list):
        return [str(v).strip() for v in val if str(v).strip()]
    s = str(val)
    # replace delimiters by comma then split
    for d in delimiters:
        s = s.replace(d, ",")
    parts = [p.strip() for p in s.split(",") if p.strip()]
    return parts

def save_series_and_plot(series, name, kind="bar", xlabel=None, topn=None, rotate=45):
    """Save series -> CSV and create plot PNG. Return filenames."""
    if series is None or len(series)==0:
        print(f"[WARN] No data for {name}")
        return None, None
    # optionally take topn
    s = series.copy()
    if topn:
        s = s.sort_values(ascending=False).head(topn)
    else:
        s = s.sort_values(ascending=False)
    csv_path = CSV_DIR / f"{name}.csv"
    s.to_csv(csv_path, header=True)
    # plot
    plt.figure(figsize=(10,6) if kind=="bar" else (8,5))
    if kind=="bar":
        s.plot(kind="bar")
    elif kind=="hist":
        plt.hist(series.dropna(), bins=20)
    else:
        s.plot(kind=kind)
    plt.title(name.replace("_"," ").title())
    if xlabel:
        plt.xlabel(xlabel)
    plt.ylabel("Count")
    plt.xticks(rotation=rotate, ha="right")
    plt.tight_layout()
    img_path = IMG_DIR / f"{name}.png"
    plt.savefig(img_path, dpi=150)
    plt.close()
    print(f"[SAVED] {img_path} and {csv_path}")
    return str(csv_path), str(img_path)

# ---------- Load dataset ----------
print("Loading dataset:", INPUT_FILE)
df = read_input(INPUT_FILE)
print("Loaded shape:", df.shape)
print("Columns:", list(df.columns))

# Standardize whitespace in column names
df.columns = [c.strip() if isinstance(c,str) else c for c in df.columns]

# ---------- Identify important columns ----------
col_journal = find_col(df, "journal", "source")
col_year    = find_col(df, "year", "publication year", "pub year")
col_country = find_col(df, "country", "countries", "affiliation country")
col_type    = find_col(df, "article type", "type", "document type")
col_keywords= find_col(df, "keyword", "keywords", "key words")
col_refs    = find_col(df, "reference", "references", "no. of references", "number of references")
col_inst    = find_col(df, "institution", "affiliation", "author institution")
col_citations = find_col(df, "citation", "citations", "times cited")
col_authors = find_col(df, "author", "authors", "author names")
col_first_author = find_col(df, "first author", "1st author", "first_author")
col_num_authors = find_col(df, "number of authors", "authors count", "no. authors", "author count")
col_content = find_col(df, "content", "topic", "subject", "contents")
col_num_keywords = find_col(df, "number of keywords", "num keywords", "keywords count")

print("Detected columns (best guess):")
print("Journal:", col_journal)
print("Year:", col_year)
print("Country:", col_country)
print("Article Type:", col_type)
print("Keywords:", col_keywords)
print("Number of Keywords:", col_num_keywords)
print("References:", col_refs)
print("Institution:", col_inst)
print("Citations:", col_citations)
print("Authors:", col_authors)
print("First author:", col_first_author)
print("Num authors:", col_num_authors)
print("Content:", col_content)

# ---------- Clean some fields ----------
def clean_series_strip_lower(df, col):
    if not col or col not in df.columns:
        return None
    return df[col].astype(str).str.strip()

# Try to coerce year to numeric (for covid window etc.)
if col_year and col_year in df.columns:
    df['_year_numeric'] = pd.to_numeric(df[col_year], errors='coerce')
else:
    df['_year_numeric'] = pd.NA

# ---------- ANALYSES 1-16 ----------
# Each step: compute table/series or pivot, save CSV and PNG

# 1. Articles by country
if col_country:
    country_series = df[col_country].dropna().astype(str).str.strip().value_counts()
    save_series_and_plot(country_series, "articles_by_country", kind="bar", xlabel="Country", topn=50)
else:
    country_series = None
    print("[WARN] Country column not found")

# 2. Article Types
if col_type:
    type_series = df[col_type].dropna().astype(str).str.strip().value_counts()
    save_series_and_plot(type_series, "article_types", kind="bar", xlabel="Article Type")
else:
    type_series = None
    print("[WARN] Article type column not found")

# 3. Top Keywords (tokenize)
if col_keywords:
    kws = df[col_keywords].dropna().apply(lambda v: tokens_from_cell(v)).explode().dropna().astype(str).str.lower().str.strip()
    kw_series = kws.value_counts()
    save_series_and_plot(kw_series, "top_keywords", kind="bar", xlabel="Keyword", topn=50)
else:
    kw_series = None
    print("[WARN] Keywords column not found")

# 4. Number of Keywords per Article
if col_num_keywords and col_num_keywords in df.columns:
    try:
        numk = pd.to_numeric(df[col_num_keywords], errors='coerce')
        # underlying CSV and plot
        numk.value_counts().sort_index().to_csv(CSV_DIR/"num_keywords_dist.csv", header=True)
        plt.figure(figsize=(8,5))
        plt.hist(numk.dropna(), bins=20)
        plt.title("Number of Keywords per Article")
        plt.xlabel("Number of Keywords")
        plt.ylabel("Frequency")
        plt.tight_layout()
        plt.savefig(IMG_DIR/"num_keywords_hist.png")
        plt.close()
        print("[SAVED] num_keywords_hist.png + csv")
    except Exception as e:
        print("[WARN] Error processing number of keywords:", e)
else:
    # fallback: compute from KEYWORDS column if present
    if col_keywords:
        kw_count_series = df[col_keywords].fillna("").apply(lambda v: len(tokens_from_cell(v)))
        kw_count_series.value_counts().sort_index().to_csv(CSV_DIR/"num_keywords_dist.csv", header=True)
        plt.figure(figsize=(8,5))
        plt.hist(kw_count_series, bins=range(0,int(kw_count_series.max())+2))
        plt.title("Inferred Number of Keywords per Article")
        plt.xlabel("Number of Keywords")
        plt.ylabel("Frequency")
        plt.tight_layout()
        plt.savefig(IMG_DIR/"num_keywords_hist_inferred.png")
        plt.close()
        print("[SAVED] num_keywords_hist_inferred.png + csv")
    else:
        print("[WARN] No keywords info to compute keyword counts")

# 5. Distribution of Number of References
if col_refs and col_refs in df.columns:
    refs = pd.to_numeric(df[col_refs], errors='coerce')
    refs.value_counts().sort_index().to_csv(CSV_DIR/"references_distribution.csv", header=True)
    plt.figure(figsize=(8,5))
    plt.hist(refs.dropna(), bins=20)
    plt.title("Distribution of Number of References")
    plt.xlabel("Number of References")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(IMG_DIR/"references_hist.png")
    plt.close()
    print("[SAVED] references_hist.png + csv")
else:
    print("[WARN] References column not found")

# 6. Citations distribution
if col_citations and col_citations in df.columns:
    cites = pd.to_numeric(df[col_citations], errors='coerce')
    cites.value_counts().sort_index().to_csv(CSV_DIR/"citations_distribution.csv", header=True)
    plt.figure(figsize=(8,5))
    plt.hist(cites.dropna(), bins=20)
    plt.title("Citations Distribution")
    plt.xlabel("Citations")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(IMG_DIR/"citations_hist.png")
    plt.close()
    print("[SAVED] citations_hist.png + csv")
else:
    print("[WARN] Citations column not found")

# 7. Covid-period vs other years by year (covid years 2020-2022)
if '_year_numeric' in df.columns and not df['_year_numeric'].isna().all():
    df['_is_covid'] = df['_year_numeric'].between(2020, 2022)
    ctab = pd.crosstab(df['_year_numeric'], df['_is_covid'])
    ctab.to_csv(CSV_DIR/"covid_vs_other_by_year.csv")
    # Plot stacked bar
    ctab.plot(kind='bar', stacked=True, figsize=(12,6))
    plt.title("Covid-period (2020-2022) vs Others by Year")
    plt.xlabel("Year")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(IMG_DIR/"covid_vs_other_by_year.png")
    plt.close()
    print("[SAVED] covid_vs_other_by_year.png + csv")
else:
    print("[WARN] Year data not available for covid analysis")

# 8. Top Authors by Article Count (tokenize authors)
if col_authors and col_authors in df.columns:
    authors = df[col_authors].dropna().apply(lambda v: tokens_from_cell(v, delimiters=[",",";","\n"," and "])).explode().dropna().str.strip()
    author_series = authors.value_counts()
    save_series_and_plot(author_series, "top_authors_by_article_count", kind="bar", xlabel="Author", topn=50)
else:
    print("[WARN] Authors column not found")

# 9. Content/Topic Distribution
if col_content and col_content in df.columns:
    content_series = df[col_content].dropna().astype(str).str.strip().value_counts()
    save_series_and_plot(content_series, "content_topic_distribution", kind="bar", xlabel="Content", topn=50)
else:
    print("[WARN] Content column not found")

# 10. Top First Authors
# If First author column exists use it, otherwise extract from Authors
if col_first_author and col_first_author in df.columns:
    first_series = df[col_first_author].dropna().astype(str).str.strip().value_counts()
    save_series_and_plot(first_series, "top_first_authors", kind="bar", xlabel="First Author", topn=50)
elif col_authors and col_authors in df.columns:
    firsts = df[col_authors].dropna().apply(lambda v: tokens_from_cell(v, delimiters=[",",";","\n"," and "])[0] if tokens_from_cell(v, delimiters=[",",";","\n"," and "]) else None)
    firsts = firsts.dropna().str.strip()
    first_series = firsts.value_counts()
    save_series_and_plot(first_series, "top_first_authors_inferred", kind="bar", xlabel="First Author", topn=50)
else:
    print("[WARN] No first-author info")

# 11. ARTICLE TYPE BY JOURNAL (top journals)  <-- re-analysis (clean names and top selection)
if col_type and col_journal:
    # Clean strings
    df['_journal_clean'] = df[col_journal].fillna("Unknown").astype(str).str.strip()
    df['_type_clean'] = df[col_type].fillna("Unknown").astype(str).str.strip()
    # choose top journals by volume
    top_journals = df['_journal_clean'].value_counts().head(15).index.tolist()
    pivot_11 = pd.crosstab(df[df['_journal_clean'].isin(top_journals)]['_journal_clean'],
                          df[df['_journal_clean'].isin(top_journals)]['_type_clean'])
    pivot_11.to_csv(CSV_DIR/"article_type_by_journal_top.csv")
    # stacked bar
    pivot_11.plot(kind='bar', stacked=True, figsize=(12,7))
    plt.title("Article Type by Journal (Top Journals)")
    plt.xlabel("Journal")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(IMG_DIR/"article_type_by_journal_top.png")
    plt.close()
    print("[SAVED] article_type_by_journal_top.png + csv")
else:
    print("[WARN] Cannot compute Article Type by Journal (missing columns)")

# 12. CONTENT BY JOURNAL (Top Journals) <-- re-analysis (clean & top)
if col_content and col_journal:
    df['_content_clean'] = df[col_content].fillna("Unknown").astype(str).str.strip()
    df['_journal_clean'] = df[col_journal].fillna("Unknown").astype(str).str.strip()
    top_journals = df['_journal_clean'].value_counts().head(15).index.tolist()
    pivot_12 = pd.crosstab(df[df['_journal_clean'].isin(top_journals)]['_journal_clean'],
                           df[df['_journal_clean'].isin(top_journals)]['_content_clean'])
    pivot_12.to_csv(CSV_DIR/"content_by_journal_top.csv")
    pivot_12.plot(kind='bar', stacked=True, figsize=(12,7))
    plt.title("Content by Journal (Top Journals)")
    plt.xlabel("Journal")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(IMG_DIR/"content_by_journal_top.png")
    plt.close()
    print("[SAVED] content_by_journal_top.png + csv")
else:
    print("[WARN] Cannot compute Content by Journal (missing columns)")

# 13. Content Comparison by Article Type
if col_content and col_type:
    pivot_13 = pd.crosstab(df[col_type].fillna("Unknown").astype(str).str.strip(), df[col_content].fillna("Unknown").astype(str).str.strip())
    pivot_13.to_csv(CSV_DIR/"content_by_article_type.csv")
    # plot for top content categories
    top_contents = df[col_content].value_counts().head(10).index.tolist()
    pivot_13_top = pivot_13[top_contents] if set(top_contents).issubset(pivot_13.columns) else pivot_13
    pivot_13_top.plot(kind='bar', stacked=True, figsize=(12,7))
    plt.title("Content by Article Type (Top Contents)")
    plt.xlabel("Article Type")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(IMG_DIR/"content_by_article_type.png")
    plt.close()
    print("[SAVED] content_by_article_type.png + csv")
else:
    print("[WARN] Missing columns for content vs article type")

# 14. Content by Country
if col_content and col_country:
    pivot_14 = pd.crosstab(df[col_country].fillna("Unknown").astype(str).str.strip(), df[col_content].fillna("Unknown").astype(str).str.strip())
    pivot_14.to_csv(CSV_DIR/"content_by_country.csv")
    top_countries = df[col_country].value_counts().head(15).index.tolist()
    pivot_14_top = pivot_14.loc[[c for c in top_countries if c in pivot_14.index]]
    pivot_14_top.plot(kind='bar', stacked=True, figsize=(12,7))
    plt.title("Content by Country (Top Countries)")
    plt.xlabel("Country")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(IMG_DIR/"content_by_country_top.png")
    plt.close()
    print("[SAVED] content_by_country_top.png + csv")
else:
    print("[WARN] Missing columns for content by country")

# 15. Top Content topics over years (time-series)
if col_content and '_year_numeric' in df.columns and not df['_year_numeric'].isna().all():
    pivot_15 = pd.crosstab(df['_year_numeric'], df[col_content].fillna("Unknown").astype(str).str.strip())
    pivot_15.to_csv(CSV_DIR/"top_content_topics_over_years.csv")
    # select top topics
    top_topics = df[col_content].value_counts().head(8).index.tolist()
    pivot_15_top = pivot_15[top_topics] if set(top_topics).issubset(pivot_15.columns) else pivot_15
    pivot_15_top.plot(kind='line', figsize=(12,7))
    plt.title("Top Content Topics Over Years")
    plt.xlabel("Year")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(IMG_DIR/"top_content_topics_over_years.png")
    plt.close()
    print("[SAVED] top_content_topics_over_years.png + csv")
else:
    print("[WARN] Cannot compute top content topics over years (missing year or content)")

# 16. Content by institution (top institutions)  <-- re-analysis (clean & top)
if col_content and col_inst:
    df['_inst_clean'] = df[col_inst].fillna("Unknown").astype(str).str.strip()
    df['_content_clean'] = df[col_content].fillna("Unknown").astype(str).str.strip()
    # UNNEST if multiple institutions per row (split common delimiters)
    inst_exp = df.assign(_inst_split=df['_inst_clean'].apply(lambda v: tokens_from_cell(v))).explode('_inst_split')
    inst_exp['_inst_split'] = inst_exp['_inst_split'].astype(str).str.strip()
    top_insts = inst_exp['_inst_split'].value_counts().head(15).index.tolist()
    pivot_16 = pd.crosstab(inst_exp[inst_exp['_inst_split'].isin(top_insts)]['_inst_split'],
                           inst_exp[inst_exp['_inst_split'].isin(top_insts)]['_content_clean'])
    pivot_16.to_csv(CSV_DIR/"content_by_institution_top.csv")
    pivot_16.plot(kind='bar', stacked=True, figsize=(12,7))
    plt.title("Content by Institution (Top Institutions)")
    plt.xlabel("Institution")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(IMG_DIR/"content_by_institution_top.png")
    plt.close()
    print("[SAVED] content_by_institution_top.png + csv")
else:
    print("[WARN] Missing columns for content by institution")

# ---------- Export cleaned dataset for WEKA ----------
# Optionally: perform minimal cleaning (strip strings)
df_clean = df.copy()
for c in df_clean.select_dtypes(include=["object"]).columns:
    df_clean[c] = df_clean[c].astype(str).str.strip()

df_clean.to_csv(OUT_DIR/"dataset_for_weka.csv", index=False)
print("[SAVED] dataset_for_weka.csv")

# ---------- Create Excel workbook with histograms (one sheet per histogram PNG) ----------
# We will embed these PNG files into separate sheets for easy copy/paste into thesis.
png_files = sorted([p for p in IMG_DIR.glob("*.png")])
if png_files:
    print("Creating Excel workbook with embedded histogram images:", HIST_EXCEL)
    workbook = xlsxwriter.Workbook(str(HIST_EXCEL))
    for img_path in png_files:
        sheet_name = img_path.stem[:30]  # limit sheet name length
        worksheet = workbook.add_worksheet(sheet_name)
        # write the CSV data filename if exists
        csv_equiv = CSV_DIR / f"{img_path.stem}.csv"
        text_row = 0
        if csv_equiv.exists():
            worksheet.write(text_row, 0, f"CSV: {csv_equiv.name}")
            text_row += 1
            # optionally write first few rows of CSV for quick preview
            try:
                preview = pd.read_csv(csv_equiv).head(50)
                # write preview
                for r, row in enumerate(preview.itertuples(index=False), start=text_row):
                    for c, val in enumerate(row):
                        worksheet.write(r, c, str(val))
                text_row = r + 2
            except Exception:
                pass
        # insert image below preview (row= text_row+1, col=0)
        worksheet.insert_image(text_row+1, 0, str(img_path), {'x_scale': 0.8, 'y_scale': 0.8})
    workbook.close()
    print("[SAVED] histograms_for_thesis.xlsx")
else:
    print("[WARN] No PNG figures found to embed in Excel workbook")

print("\nAll tasks completed. Outputs saved in folder:", OUT_DIR.resolve())
